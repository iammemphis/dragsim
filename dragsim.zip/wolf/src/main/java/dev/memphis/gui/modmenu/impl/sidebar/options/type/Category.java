/*
 * Copyright (c) 2022 Memphis
 * GNU Lesser General Public License v3.0
 */

package dev.memphis.gui.modmenu.impl.sidebar.options.type;

import dev.memphis.DragSim;
import dev.memphis.feature.option.Option;
import dev.memphis.gui.modmenu.impl.Panel;
import dev.memphis.gui.modmenu.impl.sidebar.options.Options;
import dev.memphis.helpers.render.Helper2D;

public class Category extends Options {

    public Category(Option option, Panel panel, int y) {
        super(option, panel, y);
    }

    @Override
    public void renderOption(int mouseX, int mouseY) {
        DragSim.INSTANCE.fontHelper.size20.drawString(
                option.getName(),
                panel.getX() + 20,
                panel.getY() + panel.getH() + getY() + 6,
                0x90ffffff
        );
        Helper2D.drawRectangle(panel.getX() + 20, panel.getY() + panel.getH() + getY() + 20, panel.getW() - 40, 1, 0x40ffffff);
    }

    @Override
    public void mouseClicked(int mouseX, int mouseY, int mouseButton) {

    }

    @Override
    public void mouseReleased(int mouseX, int mouseY, int state) {

    }
}
