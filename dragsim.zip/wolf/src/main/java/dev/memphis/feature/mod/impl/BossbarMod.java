package dev.memphis.feature.mod.impl;

import dev.memphis.feature.mod.Mod;
import dev.memphis.feature.mod.Type;

public class BossbarMod extends Mod {
    public BossbarMod() {
        super(
                "Bossbar",
                "Adds tweaks to the Bossbar",
                Type.Tweaks
        );
    }
}
