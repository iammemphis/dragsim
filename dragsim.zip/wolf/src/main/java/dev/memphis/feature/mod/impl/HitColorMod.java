package dev.memphis.feature.mod.impl;

import dev.memphis.DragSim;
import dev.memphis.feature.mod.Mod;
import dev.memphis.feature.mod.Type;
import dev.memphis.feature.setting.Setting;

import java.awt.*;

public class HitColorMod extends Mod {
    public HitColorMod() {
        super(
                "Hit Color",
                "Changes the color of damaged entities.",
                Type.Visual
        );

        DragSim.INSTANCE.settingManager.addSetting(new Setting("Damage Color", this, new Color(255, 0, 0), new Color(255, 0, 0), 0, new float[]{145, 0}));
        DragSim.INSTANCE.settingManager.addSetting(new Setting("Alpha", this, 255, 80));
    }
}
