/*
 * Copyright (c) 2022 Memphis
 * GNU Lesser General Public License v3.0
 */

package dev.memphis.feature.mod.impl;

import dev.memphis.DragSim;
import dev.memphis.feature.mod.Mod;
import dev.memphis.feature.mod.Type;
import dev.memphis.feature.setting.Setting;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.potion.Potion;
import net.minecraftforge.event.entity.player.AttackEntityEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class ParticleMultiplierMod extends Mod {

    public ParticleMultiplierMod() {
        super(
                "ParticleMultiplier",
                "Multiplies or adds Particles by a given amount.",
                Type.Visual
        );

        DragSim.INSTANCE.settingManager.addSetting(new Setting("Particle Amount", this, 15, 5));
    }

    @SubscribeEvent
    public void onAttack(AttackEntityEvent e) {
        if (e.target instanceof EntityLivingBase) {
            boolean doCriticalDamage =
                    DragSim.INSTANCE.mc.thePlayer.fallDistance > 0.0F &&
                    !DragSim.INSTANCE.mc.thePlayer.onGround &&
                    !DragSim.INSTANCE.mc.thePlayer.isOnLadder() &&
                    !DragSim.INSTANCE.mc.thePlayer.isInWater() &&
                    !DragSim.INSTANCE.mc.thePlayer.isPotionActive(Potion.blindness) &&
                            DragSim.INSTANCE.mc.thePlayer.ridingEntity == null;

            for (int i = 0; i < getAmount(); i++) {
                DragSim.INSTANCE.mc.thePlayer.onEnchantmentCritical(e.target);
                if (doCriticalDamage) {
                    DragSim.INSTANCE.mc.thePlayer.onCriticalHit(e.target);
                }
            }

        }
    }

    private float getAmount() {
        return DragSim.INSTANCE.settingManager.getSettingByModAndName(getName(), "Particle Amount").getCurrentNumber();
    }
}
