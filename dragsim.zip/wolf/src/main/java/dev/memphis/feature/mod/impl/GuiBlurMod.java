/*
 * Copyright (c) 2022 Memphis
 * GNU Lesser General Public License v3.0
 */

package dev.memphis.feature.mod.impl;

import dev.memphis.DragSim;
import dev.memphis.feature.mod.Mod;
import dev.memphis.feature.mod.Type;
import net.minecraft.client.gui.GuiChat;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.client.event.GuiOpenEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class GuiBlurMod extends Mod {

    public GuiBlurMod() {
        super(
                "GuiBlur",
                "Adds a blur effect to opened GUIs.",
                Type.Visual
        );
    }

    @SubscribeEvent
    public void onGuiOpen(GuiOpenEvent e) {
        if (!(e.gui instanceof GuiChat)) {
            DragSim.INSTANCE.mc.entityRenderer.loadShader(
                    new ResourceLocation("shaders/post/blur.json"));
        }
        if (e.gui == null) {
            if (DragSim.INSTANCE.mc.entityRenderer.getShaderGroup() != null) {
                DragSim.INSTANCE.mc.entityRenderer.getShaderGroup().deleteShaderGroup();
            }
        }
    }
}
