/*
 * Copyright (c) 2022 Memphis
 * GNU Lesser General Public License v3.0
 */

package dev.memphis.feature.mod.impl;

import dev.memphis.DragSim;
import dev.memphis.feature.mod.Mod;
import dev.memphis.feature.mod.Type;
import dev.memphis.feature.setting.Setting;

import java.awt.*;

public class DayCounterMod extends Mod {

    public DayCounterMod() {
        super(
                "Day Counter",
                "Shows you the current Minecraft Day on the HUD.",
                Type.Hud
        );

        String[] mode = {"Modern", "Legacy"};
        DragSim.INSTANCE.settingManager.addSetting(new Setting("Mode", this, "Modern", 0, mode));
        DragSim.INSTANCE.settingManager.addSetting(new Setting("Background", this, true));
        DragSim.INSTANCE.settingManager.addSetting(new Setting("Font Color", this, new Color(255, 255, 255), new Color(255, 0, 0), 0, new float[]{0, 0}));
    }
}
