package dev.memphis.feature.mod.impl;

import dev.memphis.DragSim;
import dev.memphis.feature.mod.Mod;
import dev.memphis.feature.mod.Type;
import dev.memphis.feature.setting.Setting;

public class TimeChangerMod extends Mod {
    public TimeChangerMod() {
        super(
                "TimeChanger",
                "Changes the time of the current World visually.",
                Type.Visual
        );

        DragSim.INSTANCE.settingManager.addSetting(new Setting("Offset", this, 12000, 0));
        DragSim.INSTANCE.settingManager.addSetting(new Setting("Speed", this, 50, 1));
    }
}
