/*
 * Copyright (c) 2022 Memphis
 * GNU Lesser General Public License v3.0
 */

package dev.memphis.config;

import com.google.gson.Gson;
import dev.memphis.DragSim;
import dev.memphis.feature.mod.Mod;
import dev.memphis.feature.option.Option;
import dev.memphis.feature.setting.Setting;
import dev.memphis.gui.Style;
import dev.memphis.helpers.OSHelper;

import java.awt.*;
import java.io.FileNotFoundException;
import java.io.FileReader;

public class ConfigLoader {

    /**
     * Loads the config from .minecraft/memphis/config.json
     */

    public static void loadConfig() {
        FileReader reader = null;
        try {
            reader = new FileReader(OSHelper.getDragSimDirectory() + "config.json");
        } catch (FileNotFoundException e) {
            System.out.println(e.getMessage());
        }

        if(reader == null) {
            return;
        }

        Config config = new Gson().fromJson(reader, Config.class);

        for (int i = 0; i < config.getConfig().size(); i++) {
            Mod mod = DragSim.INSTANCE.modManager.getMods().get(i);
            mod.setToggled(config.getConfig().get(i).isToggled());
            for (int j = 0; j < config.getConfig().get(i).getSettings().size(); j++) {
                Setting configSetting = config.getConfig().get(i).getSettings().get(j);
                Setting clientSetting = DragSim.INSTANCE.settingManager.getSettingsByMod(mod).get(j);
                switch (config.getConfig().get(i).getSettings().get(j).getMode()) {
                    case "CheckBox":
                        boolean toggled = configSetting.isCheckToggled();
                        clientSetting.setCheckToggled(toggled);
                        break;
                    case "Slider":
                        float amount = configSetting.getCurrentNumber();
                        clientSetting.setCurrentNumber(amount);
                        break;
                    case "ModePicker":
                        String mode = configSetting.getCurrentMode();
                        int index = configSetting.getModeIndex();
                        clientSetting.setCurrentMode(mode);
                        clientSetting.setModeIndex(index);
                        break;
                    case "ColorPicker":
                        Color color = configSetting.getColor();
                        Color sideColor = configSetting.getSideColor();
                        float sideSlider = configSetting.getSideSlider();
                        float[] mainSlider = configSetting.getMainSlider();
                        clientSetting.setColor(color);
                        clientSetting.setSideColor(sideColor);
                        clientSetting.setSideSlider(sideSlider);
                        clientSetting.setMainSlider(mainSlider);
                        break;
                    case "CellGrid":
                        boolean[] cells = configSetting.getCells();
                        clientSetting.setCells(cells);
                        break;
                    case "Keybinding":
                        int key = configSetting.getKey();
                        clientSetting.setKey(key);
                        break;
                }
            }

            if (DragSim.INSTANCE.hudEditor.getHudMod(mod.getName()) != null) {
                DragSim.INSTANCE.hudEditor.getHudMod(mod.getName()).setX(config.getConfig().get(i).getPositions()[0]);
                DragSim.INSTANCE.hudEditor.getHudMod(mod.getName()).setY(config.getConfig().get(i).getPositions()[1]);
                DragSim.INSTANCE.hudEditor.getHudMod(mod.getName()).setSize(config.getConfig().get(i).getSize());
            }
        }

        for(int i = 0; i < config.getOptionsConfigList().size(); i++){
            Option configOption = config.getOptionsConfigList().get(i);
            Option clientOption = DragSim.INSTANCE.optionManager.getOptions().get(i);
            switch (configOption.getMode()) {
                case "CheckBox":
                    boolean toggled = configOption.isCheckToggled();
                    clientOption.setCheckToggled(toggled);
                    break;
                case "Slider":
                    float amount = configOption.getCurrentNumber();
                    clientOption.setCurrentNumber(amount);
                    break;
                case "ModePicker":
                    String mode = configOption.getCurrentMode();
                    int index = configOption.getModeIndex();
                    clientOption.setCurrentMode(mode);
                    clientOption.setModeIndex(index);
                    break;
                case "ColorPicker":
                    Color color = configOption.getColor();
                    Color sideColor = configOption.getSideColor();
                    float sideSlider = configOption.getSideSlider();
                    float[] mainSlider = configOption.getMainSlider();
                    clientOption.setColor(color);
                    clientOption.setSideColor(sideColor);
                    clientOption.setSideSlider(sideSlider);
                    clientOption.setMainSlider(mainSlider);
                    break;
                case "CellGrid":
                    boolean[] cells = configOption.getCells();
                    clientOption.setCells(cells);
                    break;
                case "Keybinding":
                    int key = configOption.getKey();
                    clientOption.setKey(key);
                    break;
            }
        }

        Style.setDarkMode(config.isDarkMode());
        Style.setSnapping(config.isSnapping());
    }
}
