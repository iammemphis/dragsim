/*
 * Copyright (c) 2022 Memphis
 * GNU Lesser General Public License v3.0
 */

package dev.memphis;

import dev.memphis.config.ConfigLoader;
import dev.memphis.config.ConfigSaver;
import dev.memphis.feature.mod.ModManager;
import dev.memphis.feature.option.OptionManager;
import dev.memphis.feature.setting.SettingManager;
import dev.memphis.gui.hudeditor.HudEditor;
import dev.memphis.helpers.CpsHelper;
import dev.memphis.helpers.MessageHelper;
import dev.memphis.helpers.font.FontHelper;
import net.minecraft.client.Minecraft;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.Mod.EventHandler;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import org.lwjgl.opengl.Display;

import java.io.IOException;

@Mod(
        modid = DragSim.modID,
        name = DragSim.modName,
        version = DragSim.modVersion,
        acceptedMinecraftVersions = "[1.8.9]"
)
public class DragSim {

    @Mod.Instance()
    public static DragSim INSTANCE;

    public static final String modID = "dragsim";
    public static final String modName = "DragSim";
    public static final String modVersion = "1.4.0 [1.8.9]";

    public Minecraft mc = Minecraft.getMinecraft();

    public ModManager modManager;
    public SettingManager settingManager;
    public HudEditor hudEditor;
    public OptionManager optionManager;
    public FontHelper fontHelper;
    public CpsHelper cpsHelper;
    public MessageHelper messageHelper;

    /**
     * Initializes the client
     */
    @EventHandler
    public void init(FMLInitializationEvent event) throws IOException {
        Display.setTitle(DragSim.modName + " Client " + DragSim.modVersion);
        registerEvents(
                cpsHelper = new CpsHelper(),
                settingManager = new SettingManager(),
                modManager = new ModManager(),
                optionManager = new OptionManager(),
                hudEditor = new HudEditor(),
                fontHelper = new FontHelper(),
                messageHelper = new MessageHelper()
        );

        if (!ConfigSaver.configExists()) {
            ConfigSaver.saveConfig();
        }
        ConfigLoader.loadConfig();
        fontHelper.init();

        Runtime.getRuntime().addShutdownHook(new Thread(ConfigSaver::saveConfig));
    }

    private void registerEvents(Object... events) {
        for (Object event : events) {
            MinecraftForge.EVENT_BUS.register(event);
        }
    }
}